# CS110-Graphics

CS110-Graphics is a graphical addiction to Python, written in Python 2.7, for use in teaching environments. It was originally developed during the summer of 2017 for Hamilton College's Computer Science department.

The backing environment is based off of Tkinter's canvas object.

# Usage

There are multiple versions - the most recent one is cs110graphics.py. Import it using "from cs110graphics import \*".

# Class Hierarchy

